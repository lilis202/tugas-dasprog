def luas_segitiga(alas, tinggi):
    return 1 / 2 * alas * tinggi